package com.musiqle.Musiqle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MusiqleApplicationTests {

	@Test
	void contextLoads() {
	}

}
